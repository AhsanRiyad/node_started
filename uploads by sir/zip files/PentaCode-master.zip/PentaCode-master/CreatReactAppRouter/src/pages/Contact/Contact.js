import React, { Component } from 'react';
import './Contact.css';

class Contact extends Component {
  render() {
    return (
      <div className="Contact">
        <h1>Contact Page</h1>
      </div>
    );
  }
}

export default Contact;
