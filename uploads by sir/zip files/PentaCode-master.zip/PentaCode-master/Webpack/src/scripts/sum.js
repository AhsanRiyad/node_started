import add from './add';

let sum = add(5, 4);

export default sum = sum;
