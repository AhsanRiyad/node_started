export default function sum(value1, value2) {
	return value1 - value2;
}
