import {getBreakfast as MyOwnGetBreakfast} from './foo';
