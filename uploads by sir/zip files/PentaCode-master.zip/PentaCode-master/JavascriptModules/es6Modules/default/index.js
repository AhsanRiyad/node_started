import foo from './foo';
import whateverIWant from './foo';
import nameDoesntMatter from './foo';