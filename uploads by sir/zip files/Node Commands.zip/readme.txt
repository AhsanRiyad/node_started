Download node installer from nodejs.org.
I prefer the LTS version (whatever version it is). Currently it is 8.12.0

Download Link: https://nodejs.org/dist/v8.12.0/node-v8.12.0-x64.msi

Install with default options (only next->next->next).
All the environment variables will be set up automatically.
Check the installation by running the command "node -v" in the command prompt. It will show the version of node installed.
Create a .js file with any name (app.js preferred)
Write codes and save the file

Run the file from the command prompt using the following command

node <path/to/your/file>
or
node <path/to/your/file.js>

Specifing the file extension at the end is optional