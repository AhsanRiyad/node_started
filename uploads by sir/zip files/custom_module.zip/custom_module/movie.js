module.exports= 
{
	favMovie: "ABCD"
}
