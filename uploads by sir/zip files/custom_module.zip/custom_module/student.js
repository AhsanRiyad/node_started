

//module.exports.stdName = name;
//module.exports.printName = getName;

module.exports = {
	name : "ABC",
	age : 23,
	getName: function(){
		return this.name;
	}	
};