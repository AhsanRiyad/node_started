/*var me = require('./movie');
me.favMovie = "FNF"
console.log("Me: "+ me.favMovie);

var you = require('./movie');
you.favMovie = "Dhaka Attack"
console.log("You: "+ you.favMovie);*/


var fs = require('fs');
var path = require('path');

//fs.writeFileSync("data.txt", "hbsdfbhjf sdf hjsf hjdf sdfh sd");
//var data = fs.readFileSync('data.txt');
//console.log(data);


/*var filename = "C://windows\\///abc//a\\dd/sss/abc.js";
console.log(path.dirname(filename));
console.log(path.extname(filename));
console.log(path.normalize(filename));
*/



