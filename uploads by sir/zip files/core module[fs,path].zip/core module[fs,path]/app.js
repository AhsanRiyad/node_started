//var fs = require('fs');

//fs.writeFileSync('data.txt', 'hjad adg ajdaj sdasjhd j');
//console.log('done');

//var data = fs.readFileSync('data.txt');
//console.log(data.toString());

var path = require('path');

var filename = "C://windows\\//jhjasdghj///////asdsd/sdgyasd.exe.dd";

console.log(path.dirname(filename));
console.log(path.extname(filename));
console.log(path.normalize(filename));



